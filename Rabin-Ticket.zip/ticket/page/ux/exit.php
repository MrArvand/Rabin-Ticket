<?php




$_SESSION ['name']="";
$_SESSION ['semat']="";
$_SESSION ['code_p']="";
$_SESSION ['ok_login_i']="n";

header("location: ../ticket/index.php");
?>