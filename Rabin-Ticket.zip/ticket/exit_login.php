<?php
include('inf/f1.php');
$_SESSION ['ok_login_user_o']='n';

header("location: index.php"); 
?>