<?php




$_SESSION ['name']="";
$_SESSION ['semat']="";
$_SESSION ['code_p']="";

$_SESSION ['ok_login_user_i']="n";

 	header("location: ../index.php");
?>