<?php
if($p=="y"){?>
<div class="alert bg-success alert-dismissible fade show" role="alert">ثبت انجام شد <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>
<?php } 


if($p=="n"){?>
<div class="alert bg-danger alert-dismissible fade show" role="alert">خطایی رخ داده است و ثبت انجام نشد<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>
<?php } 


if($p=="n2"){?>

<div class="alert bg-warning alert-dismissible fade show" role="alert">خطا در اطلاعات ورودی<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>

<?php } 

