<?php

    

    
if($code == 112201){include('page/gozaresh/112201.php'); }
if($code == 112202){include('page/gozaresh/112202.php'); }
if($code == 112203){include('page/gozaresh/112203.php'); }
if($code == 112204){include('page/gozaresh/112204.php'); }
if($code == 112205){include('page/gozaresh/112205.php'); }
if($code == 112206){include('page/gozaresh/112206.php'); }
if($code == 112207){include('page/gozaresh/112207.php'); }
if($code == 112208){include('page/gozaresh/112208.php'); }
if($code == 112209){include('page/gozaresh/112209.php'); }

?>
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          