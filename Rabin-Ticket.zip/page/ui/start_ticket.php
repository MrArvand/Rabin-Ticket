
            <div class="row gx-3">
              <div class="col-sm-12">
                <div class="card mb-3">
                  <div class="card-header">
                    <h5 class="card-title">ایجاد یک تیکت پشتیبانی بر اساس تماس </h5>
                  </div>
                  <div class="card-body">



                  <form  method="post"   action="?page=s_new_ticket"  enctype="multipart/form-data">
                    <!-- Row starts -->
                    <div class="row gx-3">
                      <div class="col-lg-3 col-sm-4 col-12">
                        <div class="mb-3">
                          <label class="form-label" for="karbar_darkhast">نام درخواست دهنده</label>
                          <input   type="text" class="form-control" id="karbar_darkhast"  name="karbar_darkhast"  placeholder="نام " required>
                        </div>
                      </div>
                      
                                            <div class="col-lg-3 col-sm-4 col-12">
                        <div class="mb-3">
                          <label class="form-label" for="karbar_p_darkhast">کد درخواست دهنده</label>
                          <input   type="text" class="form-control" id="karbar_p_darkhast"  name="karbar_p_darkhast"  placeholder=" " required>
                        </div>
                      </div>
                      
                                                                  <div class="col-lg-3 col-sm-4 col-12">
                        <div class="mb-3">
                          <label class="form-label" for="tel_karbar">شماره موبایل درخواست دهنده</label>
                          <input   type="text" class="form-control" id="tel_karbar"  name="tel_karbar"  placeholder=" " required>
                        </div>
                      </div>
                      
                      <div class="col-lg-3 col-sm-4 col-12">
                        <div class="mb-3">
                          <label class="form-label" for="olaviat">ضرورت</label>
                          <select class="form-select" name="olaviat" id="olaviat">
                            <option value="1">ضروری</option>
                            <option selected value="2">متوسط</option>
                            <option value="3">معمولی</option>
                            <option value="4">پایین</option>
                          </select>
                        </div>
                      </div>


                      <div class="col-lg-3 col-sm-4 col-12">
                        <div class="mb-3">
                          <label class="form-label" for="daste">دپارتمان پشتیبانی</label>
                          <select class="form-select" name="daste" id="daste">
                          <?php

$Query_dep="SELECT*from departman where (vaziat = 'y') ORDER BY name ASC LIMIT 200";
if($Result_dep=mysqli_query($Link,$Query_dep)){
while($q_dep=mysqli_fetch_array($Result_dep)){

?>
                            <option value="<?php echo $q_dep['id']; ?>"><?php echo $q_dep['name']; ?></option>
<?php }} ?>                            
                          </select>
                        </div>
                      </div>

                      <div class="col-lg-3 col-sm-4 col-12">
                        <div class="mb-3">
                          <label class="form-label" for="sherkat">شرکت درخواست دهنده</label>
                          <select class="form-select" name="sherkat" id="sherkat">
                          <?php

								$Query_sherkat="SELECT*from sherkatha where (1)ORDER BY name DESC LIMIT 200";
   if($Result_sherkat=mysqli_query($Link,$Query_sherkat)){
 while($q_sherkat=mysqli_fetch_array($Result_sherkat)){

	 ?>
                            <option value="<?php echo $q_sherkat['code']; ?>"><?php echo $q_sherkat['name']; ?></option>
<?php }} ?>
                          </select>
                        </div>
                      </div>

                    <div class="col-lg-6 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label" for="titr">تیتر درخواست</label>
                          <input type="text" class="form-control" id="titr" name="titr" placeholder="تیتر درخواست" required>
                        </div>
                      </div>

                      <div class="col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label" for="matn">پیام</label>
                          <textarea type="text" class="form-control"  name="matn"  id="matn" placeholder="متن درخواست"
                            rows="3" required ></textarea>
                        </div>
                      </div>
                      <div class="input-group mb-5">
                      <label class="input-group-text" for="inputGroupFile01">بارگذاری</label>
                      <input name="file_peyvast" type="file" class="form-control" id="inputGroupFile01" />
                    </div>
                    <!-- Row ends -->

                  </div>
                  <div class="card-footer">
                    <div class="d-flex gap-2 justify-content-end">
                      <button type="reset" class="btn btn-outline-secondary">لغو</button>
                      <button  type="submit"  class="btn btn-primary">ثبت</button>
                    </div>
                  </div>
                  </form>
                </div>
              </div>
            </div>
            </div>
            </div>


          
          
          
            <div class="modal fade" id="selector_mod" tabindex="-1"
                      aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="selector_mod">
                            عنوان مدال
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body" id="mohtava_modal_1">
                            

                            <p>

                             </p>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">بستن</button>
                            <button type="button" class="btn btn-primary">ذخیره تغییرات </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          