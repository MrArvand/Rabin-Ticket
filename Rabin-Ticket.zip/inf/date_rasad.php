<?php
$Host="localhost";
$User="root";
$Password="";
$DBName="rasad";
$Link=mysqli_connect($Host,$User,$Password);
mysqli_select_db($Link, 'rasad');
?>