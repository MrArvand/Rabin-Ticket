<?php
//----------------------- morteza rezaie
$name_software_basic="سامانه پشتیبانی تیکت فرآهم";
$code_lisens_basic="pmNG586RTP";
$tedad_karbar_mojaz_basic="50";
$tarikh_faalsazi_basic="14020631";
$tarikh_end_poshtibani_basic="14030731";
$verjen_software_basic="1.002";
$name_malek_software_basic="هلدینگ صنعتی رهباریان";
$cssjs="1.00";
?>